"""
Churn prediction + RFM segmentation pipeline.

1. Builds point-in-time features with SQL (sql/features.sql)
2. Out-of-time validation: train on cutoff T1, test on later cutoff T2
3. Compares Logistic Regression, Random Forest, Gradient Boosting
4. Refits the best model and scores every active customer as of today
5. KMeans RFM segmentation
6. Writes predictions, segments, metrics and feature importance BACK to SQL
   and exports CSVs for Power BI

Usage:  python ml/train_and_score.py
"""
import sqlite3
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "outputs" / "ecommerce.db"
OUT = ROOT / "outputs"
SNAPSHOT = "2025-12-31"            # "today"
TEST_CUTOFF = "2025-10-02"         # SNAPSHOT - 90 days (labels fully observed)
TRAIN_CUTOFF = "2025-07-04"        # TEST_CUTOFF - 90 days
ACTIVE_WINDOW = 180                # only score customers who bought in last 180 days

CAT = ["gender", "membership_tier", "acquisition_channel"]
NUM = ["age", "tenure_days", "frequency", "total_spend", "avg_order_value", "avg_discount_pct",
       "return_rate", "cancel_rate", "cod_share", "max_categories_per_order", "recency_days",
       "orders_last_90d", "spend_last_90d", "orders_prev_90d", "order_trend", "tickets_count",
       "avg_satisfaction", "avg_resolution_hours", "tickets_last_90d"]

READABLE = {
    "recency_days": "Long gap since last order", "orders_last_90d": "Few recent orders",
    "order_trend": "Order frequency dropping", "avg_satisfaction": "Low support satisfaction",
    "tickets_count": "Many support tickets", "tickets_last_90d": "Recent support issues",
    "avg_resolution_hours": "Slow ticket resolution", "avg_discount_pct": "Discount-driven buyer",
    "frequency": "Low lifetime orders", "return_rate": "High return rate",
    "cancel_rate": "High cancellation rate", "spend_last_90d": "Low recent spend",
    "tenure_days": "New customer", "total_spend": "Low lifetime spend",
}


def q(con, file, cutoff):
    sql = (ROOT / "sql" / file).read_text()
    return pd.read_sql(sql, con, params={"cutoff": cutoff})


def dataset(con, cutoff):
    X = q(con, "features.sql", cutoff)
    X = X[X.recency_days <= ACTIVE_WINDOW]
    y = q(con, "labels.sql", cutoff)
    return X.merge(y, on="customer_id")


def make_models():
    pre_scaled = ColumnTransformer([("num", StandardScaler(), NUM),
                                    ("cat", OneHotEncoder(handle_unknown="ignore"), CAT)])
    pre_raw = ColumnTransformer([("num", "passthrough", NUM),
                                 ("cat", OneHotEncoder(handle_unknown="ignore"), CAT)])
    return {
        "Logistic Regression": Pipeline([("pre", pre_scaled),
                                         ("clf", LogisticRegression(max_iter=2000, class_weight="balanced"))]),
        "Random Forest": Pipeline([("pre", pre_raw),
                                   ("clf", RandomForestClassifier(n_estimators=400, min_samples_leaf=5,
                                                                  class_weight="balanced", n_jobs=-1,
                                                                  random_state=42))]),
        "Gradient Boosting": Pipeline([("pre", pre_raw),
                                       ("clf", HistGradientBoostingClassifier(learning_rate=0.05, max_iter=300,
                                                                              max_leaf_nodes=15,
                                                                              class_weight="balanced",
                                                                              random_state=42))]),
    }


def evaluate(y, p, thr=0.5):
    pred = (p >= thr).astype(int)
    return {"ROC_AUC": roc_auc_score(y, p), "PR_AUC": average_precision_score(y, p),
            "F1": f1_score(y, pred), "Precision": precision_score(y, pred), "Recall": recall_score(y, pred)}


def rfm_segments(con):
    rfm = pd.read_sql("""
        SELECT o.customer_id,
               CAST(julianday(:s) - julianday(MAX(o.order_date)) AS INTEGER) AS recency_days,
               COUNT(DISTINCT o.order_id) AS frequency,
               ROUND(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct/100.0)), 2) AS monetary
        FROM orders o JOIN order_items oi ON oi.order_id = o.order_id
        WHERE o.status = 'Delivered'
        GROUP BY o.customer_id""", con, params={"s": SNAPSHOT})
    Z = StandardScaler().fit_transform(np.column_stack([
        np.log1p(rfm.recency_days), np.log1p(rfm.frequency), np.log1p(rfm.monetary)]))
    km = KMeans(n_clusters=4, n_init=20, random_state=42).fit(Z)
    rfm["cluster"] = km.labels_
    # rank clusters by value: high F & M, low R  -> best
    c = pd.DataFrame(km.cluster_centers_, columns=["r", "f", "m"])
    order = (c.f + c.m - c.r).sort_values(ascending=False).index
    names = dict(zip(order, ["Champions", "Loyal", "At Risk", "Hibernating"]))
    rfm["segment_name"] = rfm.cluster.map(names)
    return rfm.drop(columns="cluster")


def main():
    con = sqlite3.connect(DB)

    # ---------- 1. Out-of-time train / test ----------
    train, test = dataset(con, TRAIN_CUTOFF), dataset(con, TEST_CUTOFF)
    print(f"Train (cutoff {TRAIN_CUTOFF}): {len(train):,} customers, churn rate {train.churned.mean():.1%}")
    print(f"Test  (cutoff {TEST_CUTOFF}): {len(test):,} customers, churn rate {test.churned.mean():.1%}\n")

    rows, fitted = [], {}
    for name, model in make_models().items():
        model.fit(train[NUM + CAT], train.churned)
        m = evaluate(test.churned, model.predict_proba(test[NUM + CAT])[:, 1])
        fitted[name] = model
        rows += [(name, k, round(v, 4)) for k, v in m.items()]
        print(f"{name:20s} " + "  ".join(f"{k}={v:.3f}" for k, v in m.items()))

    metrics = pd.DataFrame(rows, columns=["model_name", "metric", "value"])
    auc = metrics[metrics.metric == "ROC_AUC"].set_index("model_name").value
    best_name = auc.idxmax()
    metrics["is_best"] = (metrics.model_name == best_name).astype(int)
    print(f"\nBest model: {best_name} (ROC-AUC {auc.max():.3f})")

    # ---------- 2. Explainability ----------
    pi = permutation_importance(fitted[best_name], test[NUM + CAT], test.churned,
                                scoring="roc_auc", n_repeats=5, random_state=42, n_jobs=-1)
    imp = (pd.DataFrame({"feature": NUM + CAT, "importance": pi.importances_mean})
           .sort_values("importance", ascending=False))
    print("\nTop drivers:\n" + imp.head(8).to_string(index=False))

    # ---------- 3. Refit on all labelled data, score today ----------
    final = make_models()[best_name].fit(pd.concat([train, test])[NUM + CAT],
                                         pd.concat([train, test]).churned)
    joblib.dump(final, OUT / "churn_model.joblib")

    now = q(con, "features.sql", SNAPSHOT)
    now = now[now.recency_days <= ACTIVE_WINDOW].copy()
    now["churn_probability"] = final.predict_proba(now[NUM + CAT])[:, 1].round(4)
    now["predicted_churn"] = (now.churn_probability >= 0.5).astype(int)
    now["risk_segment"] = pd.cut(now.churn_probability, [-1, 0.35, 0.6, 2], labels=["Low", "Medium", "High"])
    annual_spend = now.total_spend / now.tenure_days.clip(lower=30) * 365
    now["revenue_at_risk"] = (now.churn_probability * annual_spend).round(2)

    # per-customer top driver: most "risky" z-score among the top numeric drivers
    ref = pd.concat([train, test])
    top_feats = [f for f in imp.feature if f in READABLE][:8]
    signs = {f: np.sign(ref[f].corr(ref.churned, method="spearman")) for f in top_feats}
    z = pd.DataFrame({f: signs[f] * (now[f] - ref[f].mean()) / (ref[f].std() + 1e-9) for f in top_feats})
    now["top_driver"] = z.idxmax(axis=1).map(READABLE)
    now["scored_at"] = SNAPSHOT

    preds = now[["customer_id", "churn_probability", "predicted_churn", "risk_segment",
                 "top_driver", "revenue_at_risk", "scored_at"]].astype({"risk_segment": str})

    # ---------- 4. Segmentation ----------
    seg = rfm_segments(con)

    # ---------- 5. Write back to SQL + export for Power BI ----------
    cur = con.cursor()
    for t in ["churn_predictions", "customer_segments", "model_metrics"]:
        cur.execute(f"DELETE FROM {t}")
    con.commit()
    preds.to_sql("churn_predictions", con, if_exists="append", index=False)
    seg.to_sql("customer_segments", con, if_exists="append", index=False)
    metrics.to_sql("model_metrics", con, if_exists="append", index=False)
    imp.to_sql("feature_importance", con, if_exists="replace", index=False)
    con.executescript((ROOT / "sql" / "powerbi_views.sql").read_text())

    csv_dir = ROOT / "powerbi" / "data"
    csv_dir.mkdir(parents=True, exist_ok=True)
    for t in ["vw_customer_360", "vw_sales_fact", "vw_monthly_kpis", "vw_support_fact",
              "model_metrics", "feature_importance", "products"]:
        pd.read_sql(f"SELECT * FROM {t}", con).to_csv(csv_dir / f"{t}.csv", index=False)
    con.close()

    print(f"\nScored {len(preds):,} active customers | "
          f"High risk: {(preds.risk_segment == 'High').sum():,} | "
          f"Revenue at risk: Rs {preds.revenue_at_risk.sum():,.0f}")
    print("Segments:", seg.segment_name.value_counts().to_dict())
    print(f"CSVs for Power BI written to {csv_dir}")


if __name__ == "__main__":
    main()
