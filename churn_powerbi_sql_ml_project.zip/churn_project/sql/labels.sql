-- Churn label: customer placed NO order in the 90 days AFTER :cutoff.
SELECT  c.customer_id,
        CASE WHEN EXISTS (
                 SELECT 1 FROM orders o
                 WHERE  o.customer_id = c.customer_id
                   AND  o.order_date >  :cutoff
                   AND  o.order_date <= date(:cutoff, '+90 day'))
             THEN 0 ELSE 1 END AS churned
FROM    customers c;
