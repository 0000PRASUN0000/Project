-- =====================================================================
-- Reporting views consumed by Power BI (star-schema friendly)
-- =====================================================================

-- Dimension: one row per customer, enriched with ML outputs
DROP VIEW IF EXISTS vw_customer_360;
CREATE VIEW vw_customer_360 AS
SELECT  c.customer_id, c.gender, c.age,
        CASE WHEN c.age < 25 THEN '18-24' WHEN c.age < 35 THEN '25-34'
             WHEN c.age < 45 THEN '35-44' ELSE '45+' END       AS age_group,
        c.city, c.state, c.signup_date, c.acquisition_channel, c.membership_tier,
        s.recency_days, s.frequency, s.monetary,
        COALESCE(s.segment_name, 'No Purchase')                 AS segment_name,
        p.churn_probability, p.predicted_churn,
        COALESCE(p.risk_segment, 'Inactive (Lost)')             AS risk_segment,
        p.top_driver, p.revenue_at_risk
FROM    customers c
LEFT JOIN customer_segments s ON s.customer_id = c.customer_id
LEFT JOIN churn_predictions p ON p.customer_id = c.customer_id;

-- Fact: order line level sales
DROP VIEW IF EXISTS vw_sales_fact;
CREATE VIEW vw_sales_fact AS
SELECT  oi.order_item_id, o.order_id, o.customer_id, oi.product_id,
        o.order_date, o.status, o.payment_method,
        oi.quantity, oi.unit_price, oi.discount_pct,
        ROUND(oi.quantity * oi.unit_price, 2)                                AS gross_amount,
        ROUND(oi.quantity * oi.unit_price * (1 - oi.discount_pct / 100.0), 2) AS net_amount
FROM    order_items oi
JOIN    orders o ON o.order_id = oi.order_id;

-- Fact: support tickets
DROP VIEW IF EXISTS vw_support_fact;
CREATE VIEW vw_support_fact AS
SELECT  ticket_id, customer_id, created_date, category, resolution_hours, satisfaction_score
FROM    support_tickets;

-- Aggregate: monthly KPIs (handy for trend visuals & quick checks)
DROP VIEW IF EXISTS vw_monthly_kpis;
CREATE VIEW vw_monthly_kpis AS
SELECT  strftime('%Y-%m', o.order_date)                       AS month,
        COUNT(DISTINCT o.order_id)                            AS orders,
        COUNT(DISTINCT o.customer_id)                         AS active_customers,
        ROUND(SUM(CASE WHEN o.status = 'Delivered'
                  THEN oi.quantity * oi.unit_price * (1 - oi.discount_pct / 100.0) END), 2) AS revenue,
        ROUND(AVG(CASE WHEN o.status = 'Returned' THEN 1.0 ELSE 0 END), 4) AS return_rate
FROM    orders o
JOIN    order_items oi ON oi.order_id = o.order_id
GROUP BY 1;
