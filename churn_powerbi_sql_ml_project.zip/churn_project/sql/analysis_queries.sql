-- =====================================================================
-- Business analysis queries (SQLite dialect, MySQL notes inline)
-- Showcases: CTEs, window functions, CASE, cohort analysis, ranking
-- =====================================================================

-- Q1. Monthly revenue with month-over-month growth  (LAG window function)
WITH m AS (
    SELECT strftime('%Y-%m', order_date) AS month,          -- MySQL: DATE_FORMAT(order_date,'%Y-%m')
           SUM(net_amount)               AS revenue
    FROM   vw_sales_fact WHERE status = 'Delivered'
    GROUP BY 1
)
SELECT month, ROUND(revenue, 0) AS revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
             / LAG(revenue) OVER (ORDER BY month), 1) AS mom_growth_pct
FROM m ORDER BY month;

-- Q2. Top 3 products per category by revenue  (DENSE_RANK + PARTITION BY)
SELECT * FROM (
    SELECT p.category, p.product_name, ROUND(SUM(s.net_amount), 0) AS revenue,
           DENSE_RANK() OVER (PARTITION BY p.category ORDER BY SUM(s.net_amount) DESC) AS rnk
    FROM   vw_sales_fact s JOIN products p ON p.product_id = s.product_id
    WHERE  s.status = 'Delivered'
    GROUP BY p.category, p.product_name
) WHERE rnk <= 3;

-- Q3. Signup cohort retention: % of each cohort still ordering N months later
WITH first_month AS (
    SELECT customer_id, strftime('%Y-%m', signup_date) AS cohort FROM customers
),
activity AS (
    SELECT DISTINCT o.customer_id, f.cohort,
           (CAST(strftime('%Y', o.order_date) AS INT) - CAST(substr(f.cohort,1,4) AS INT)) * 12
         + (CAST(strftime('%m', o.order_date) AS INT) - CAST(substr(f.cohort,6,2) AS INT)) AS month_n
    FROM orders o JOIN first_month f ON f.customer_id = o.customer_id
)
SELECT cohort,
       COUNT(DISTINCT CASE WHEN month_n = 0 THEN customer_id END) AS m0,
       ROUND(100.0 * COUNT(DISTINCT CASE WHEN month_n = 3  THEN customer_id END)
             / COUNT(DISTINCT CASE WHEN month_n = 0 THEN customer_id END), 1) AS m3_pct,
       ROUND(100.0 * COUNT(DISTINCT CASE WHEN month_n = 6  THEN customer_id END)
             / COUNT(DISTINCT CASE WHEN month_n = 0 THEN customer_id END), 1) AS m6_pct,
       ROUND(100.0 * COUNT(DISTINCT CASE WHEN month_n = 12 THEN customer_id END)
             / COUNT(DISTINCT CASE WHEN month_n = 0 THEN customer_id END), 1) AS m12_pct
FROM activity GROUP BY cohort ORDER BY cohort;

-- Q4. Churn risk by membership tier & acquisition channel
SELECT membership_tier, acquisition_channel,
       COUNT(*)                                    AS active_customers,
       ROUND(AVG(churn_probability) * 100, 1)      AS avg_churn_risk_pct,
       SUM(CASE WHEN risk_segment = 'High' THEN 1 ELSE 0 END) AS high_risk,
       ROUND(SUM(revenue_at_risk), 0)              AS revenue_at_risk
FROM   vw_customer_360
WHERE  churn_probability IS NOT NULL
GROUP BY 1, 2 ORDER BY avg_churn_risk_pct DESC;

-- Q5. Does support experience drive churn?  (satisfaction bands vs predicted risk)
WITH t AS (
    SELECT customer_id, AVG(satisfaction_score) AS sat, COUNT(*) AS n
    FROM support_tickets GROUP BY customer_id
)
SELECT CASE WHEN t.sat IS NULL THEN 'No tickets'
            WHEN t.sat < 2.5 THEN 'Unhappy (<2.5)'
            WHEN t.sat < 4   THEN 'Neutral (2.5-4)'
            ELSE 'Happy (4+)' END                 AS satisfaction_band,
       COUNT(*)                                   AS customers,
       ROUND(AVG(p.churn_probability) * 100, 1)   AS avg_churn_risk_pct
FROM churn_predictions p LEFT JOIN t ON t.customer_id = p.customer_id
GROUP BY 1 ORDER BY avg_churn_risk_pct DESC;

-- Q6. Retention call list: top 20 high-value customers at high risk
SELECT customer_id, city, membership_tier, segment_name,
       ROUND(churn_probability, 2) AS churn_prob, top_driver, revenue_at_risk
FROM   vw_customer_360
WHERE  risk_segment = 'High'
ORDER BY revenue_at_risk DESC
LIMIT 20;

-- Q7. Running total of revenue in 2025  (SUM OVER with frame)
SELECT order_date, ROUND(day_rev, 0) AS day_revenue,
       ROUND(SUM(day_rev) OVER (ORDER BY order_date ROWS UNBOUNDED PRECEDING), 0) AS running_revenue
FROM (SELECT order_date, SUM(net_amount) AS day_rev
      FROM vw_sales_fact WHERE status = 'Delivered' AND order_date >= '2025-01-01'
      GROUP BY order_date)
ORDER BY order_date;

-- Q8. Customers whose order frequency dropped >50% (last 90d vs previous 90d)
WITH w AS (
    SELECT customer_id,
           SUM(CASE WHEN order_date >  date('2025-12-31','-90 day') THEN 1 ELSE 0 END) AS recent,
           SUM(CASE WHEN order_date <= date('2025-12-31','-90 day')
                     AND order_date >  date('2025-12-31','-180 day') THEN 1 ELSE 0 END) AS previous
    FROM orders GROUP BY customer_id
)
SELECT w.customer_id, previous, recent, ROUND(p.churn_probability, 2) AS churn_prob
FROM w LEFT JOIN churn_predictions p ON p.customer_id = w.customer_id
WHERE previous >= 2 AND recent < previous * 0.5
ORDER BY previous - recent DESC;
