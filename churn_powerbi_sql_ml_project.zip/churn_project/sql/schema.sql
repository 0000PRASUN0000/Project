-- =====================================================================
-- E-commerce Customer Churn & Revenue Intelligence  |  Database Schema
-- Works on SQLite and MySQL 8+ (Power BI can connect to either)
-- =====================================================================

DROP TABLE IF EXISTS churn_predictions;
DROP TABLE IF EXISTS model_metrics;
DROP TABLE IF EXISTS customer_segments;
DROP TABLE IF EXISTS support_tickets;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id         INTEGER PRIMARY KEY,
    gender              VARCHAR(10),
    age                 INTEGER,
    city                VARCHAR(50),
    state               VARCHAR(50),
    signup_date         DATE NOT NULL,
    acquisition_channel VARCHAR(30),      -- Organic / Paid Ads / Referral / Social
    membership_tier     VARCHAR(20)       -- Basic / Silver / Gold
);

CREATE TABLE products (
    product_id   INTEGER PRIMARY KEY,
    product_name VARCHAR(100),
    category     VARCHAR(50),
    unit_price   DECIMAL(10,2)
);

CREATE TABLE orders (
    order_id       INTEGER PRIMARY KEY,
    customer_id    INTEGER NOT NULL,
    order_date     DATE NOT NULL,
    status         VARCHAR(20),           -- Delivered / Returned / Cancelled
    payment_method VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id INTEGER PRIMARY KEY,
    order_id      INTEGER NOT NULL,
    product_id    INTEGER NOT NULL,
    quantity      INTEGER,
    unit_price    DECIMAL(10,2),
    discount_pct  DECIMAL(5,2),
    FOREIGN KEY (order_id)   REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE support_tickets (
    ticket_id          INTEGER PRIMARY KEY,
    customer_id        INTEGER NOT NULL,
    created_date       DATE NOT NULL,
    category           VARCHAR(30),       -- Delivery / Refund / Product Quality / Payment
    resolution_hours   DECIMAL(6,1),
    satisfaction_score INTEGER,           -- 1..5
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- ---------- Tables written back by the ML pipeline ----------
CREATE TABLE churn_predictions (
    customer_id       INTEGER PRIMARY KEY,
    churn_probability DECIMAL(6,4),
    predicted_churn   INTEGER,
    risk_segment      VARCHAR(10),        -- High / Medium / Low
    top_driver        VARCHAR(60),
    revenue_at_risk   DECIMAL(12,2),
    scored_at         DATE
);

CREATE TABLE customer_segments (
    customer_id   INTEGER PRIMARY KEY,
    recency_days  INTEGER,
    frequency     INTEGER,
    monetary      DECIMAL(12,2),
    segment_name  VARCHAR(30)             -- Champions / Loyal / At Risk / Hibernating
);

CREATE TABLE model_metrics (
    model_name VARCHAR(40),
    metric     VARCHAR(30),
    value      DECIMAL(8,4),
    is_best    INTEGER
);

CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_date     ON orders(order_date);
CREATE INDEX idx_items_order     ON order_items(order_id);
CREATE INDEX idx_tickets_cust    ON support_tickets(customer_id);
