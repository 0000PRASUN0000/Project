-- =====================================================================
-- Point-in-time customer feature table (SQLite dialect)
-- :cutoff = the "as of" date. Only data ON OR BEFORE :cutoff is used,
-- which prevents data leakage when building training labels.
-- =====================================================================
WITH order_value AS (
    SELECT  o.order_id, o.customer_id, o.order_date, o.status, o.payment_method,
            SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct / 100.0)) AS net_value,
            AVG(oi.discount_pct)                                            AS avg_disc,
            COUNT(DISTINCT p.category)                                      AS n_cat
    FROM    orders o
    JOIN    order_items oi ON oi.order_id = o.order_id
    JOIN    products    p  ON p.product_id = oi.product_id
    WHERE   o.order_date <= :cutoff
    GROUP BY o.order_id
),
order_feats AS (
    SELECT  customer_id,
            COUNT(*)                                                          AS frequency,
            SUM(CASE WHEN status = 'Delivered' THEN net_value ELSE 0 END)     AS total_spend,
            AVG(net_value)                                                    AS avg_order_value,
            AVG(avg_disc)                                                     AS avg_discount_pct,
            AVG(CASE WHEN status = 'Returned'  THEN 1.0 ELSE 0 END)           AS return_rate,
            AVG(CASE WHEN status = 'Cancelled' THEN 1.0 ELSE 0 END)           AS cancel_rate,
            AVG(CASE WHEN payment_method = 'COD' THEN 1.0 ELSE 0 END)         AS cod_share,
            MAX(n_cat)                                                        AS max_categories_per_order,
            julianday(:cutoff) - julianday(MAX(order_date))                   AS recency_days,
            SUM(CASE WHEN order_date > date(:cutoff, '-90 day') THEN 1 ELSE 0 END)          AS orders_last_90d,
            SUM(CASE WHEN order_date > date(:cutoff, '-90 day') THEN net_value ELSE 0 END)  AS spend_last_90d,
            SUM(CASE WHEN order_date BETWEEN date(:cutoff, '-180 day') AND date(:cutoff, '-91 day')
                     THEN 1 ELSE 0 END)                                       AS orders_prev_90d
    FROM    order_value
    GROUP BY customer_id
),
ticket_feats AS (
    SELECT  customer_id,
            COUNT(*)                                                          AS tickets_count,
            AVG(satisfaction_score)                                           AS avg_satisfaction,
            AVG(resolution_hours)                                             AS avg_resolution_hours,
            SUM(CASE WHEN created_date > date(:cutoff, '-90 day') THEN 1 ELSE 0 END) AS tickets_last_90d
    FROM    support_tickets
    WHERE   created_date <= :cutoff
    GROUP BY customer_id
)
SELECT  c.customer_id,
        c.age, c.gender, c.membership_tier, c.acquisition_channel, c.state,
        julianday(:cutoff) - julianday(c.signup_date)     AS tenure_days,
        f.frequency, f.total_spend, f.avg_order_value, f.avg_discount_pct,
        f.return_rate, f.cancel_rate, f.cod_share, f.max_categories_per_order,
        f.recency_days, f.orders_last_90d, f.spend_last_90d, f.orders_prev_90d,
        f.orders_last_90d - f.orders_prev_90d             AS order_trend,
        COALESCE(t.tickets_count, 0)                      AS tickets_count,
        COALESCE(t.avg_satisfaction, 5)                   AS avg_satisfaction,
        COALESCE(t.avg_resolution_hours, 0)               AS avg_resolution_hours,
        COALESCE(t.tickets_last_90d, 0)                   AS tickets_last_90d
FROM    customers   c
JOIN    order_feats f ON f.customer_id = c.customer_id     -- only customers who have ordered
LEFT JOIN ticket_feats t ON t.customer_id = c.customer_id
WHERE   c.signup_date <= :cutoff;
