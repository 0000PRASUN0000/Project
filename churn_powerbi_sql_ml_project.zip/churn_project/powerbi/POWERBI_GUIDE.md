# Power BI Dashboard: Build Guide

## 1. Connect the data (choose one)

**Option A: CSV (easiest, 2 minutes)**
Home → Get Data → Text/CSV → load every file in `powerbi/data/`:
`vw_customer_360`, `vw_sales_fact`, `vw_support_fact`, `vw_monthly_kpis`, `products`, `model_metrics`, `feature_importance`.

**Option B: MySQL (shows the "live SQL" story in interviews)**
1. Load the data into MySQL (see README, "Using MySQL").
2. Get Data → MySQL database → server `localhost`, database `ecommerce`.
3. Select the views `vw_customer_360`, `vw_sales_fact`, `vw_support_fact` plus `products`, `model_metrics`, `feature_importance`.

**Option C: SQLite via ODBC.** Install the SQLite ODBC driver, create a DSN pointing to `outputs/ecommerce.db`, then Get Data → ODBC.

In Power Query, set data types: dates (`order_date`, `signup_date`, `created_date`) → Date, money columns → Decimal / Fixed decimal.

## 2. Data model (star schema)

Create a Date table: Modeling → New table:

```DAX
DimDate =
ADDCOLUMNS (
    CALENDAR ( DATE ( 2024, 1, 1 ), DATE ( 2025, 12, 31 ) ),
    "Year", YEAR ( [Date] ),
    "Month No", MONTH ( [Date] ),
    "Month", FORMAT ( [Date], "MMM YYYY" ),
    "Quarter", "Q" & QUARTER ( [Date] )
)
```
Mark it as a date table, and sort `Month` by `Month No` (or by `[Date]`).

Relationships (all single direction, many → one):

| From (many)                     | To (one)                     |
|---------------------------------|------------------------------|
| vw_sales_fact[customer_id]      | vw_customer_360[customer_id] |
| vw_sales_fact[product_id]       | products[product_id]         |
| vw_sales_fact[order_date]       | DimDate[Date]                |
| vw_support_fact[customer_id]    | vw_customer_360[customer_id] |
| vw_support_fact[created_date]   | DimDate[Date] *(inactive)*   |

## 3. DAX measures

Create a blank table called `_Measures` and add the following measures to it:

```DAX
Total Revenue =
CALCULATE ( SUM ( vw_sales_fact[net_amount] ), vw_sales_fact[status] = "Delivered" )

Total Orders = DISTINCTCOUNT ( vw_sales_fact[order_id] )

Avg Order Value = DIVIDE ( [Total Revenue], [Total Orders] )

Active Customers = DISTINCTCOUNT ( vw_sales_fact[customer_id] )

Revenue LY = CALCULATE ( [Total Revenue], SAMEPERIODLASTYEAR ( DimDate[Date] ) )

Revenue YoY % = DIVIDE ( [Total Revenue] - [Revenue LY], [Revenue LY] )

Revenue MTD = TOTALMTD ( [Total Revenue], DimDate[Date] )

Return Rate =
DIVIDE (
    CALCULATE ( DISTINCTCOUNT ( vw_sales_fact[order_id] ), vw_sales_fact[status] = "Returned" ),
    [Total Orders]
)

Avg Discount % = AVERAGE ( vw_sales_fact[discount_pct] ) / 100

-- ---------- ML / churn measures ----------
Scored Customers = COUNTROWS ( FILTER ( vw_customer_360, NOT ISBLANK ( vw_customer_360[churn_probability] ) ) )

High Risk Customers = CALCULATE ( COUNTROWS ( vw_customer_360 ), vw_customer_360[risk_segment] = "High" )

Avg Churn Risk = AVERAGE ( vw_customer_360[churn_probability] )

Predicted Churn Rate = DIVIDE ( SUM ( vw_customer_360[predicted_churn] ), [Scored Customers] )

Revenue at Risk = SUM ( vw_customer_360[revenue_at_risk] )

High Risk Revenue =
CALCULATE ( [Revenue at Risk], vw_customer_360[risk_segment] = "High" )

-- Assumes a retention campaign saves 30% of high-risk customers
Potential Savings (30% save) = [High Risk Revenue] * 0.30

-- ---------- Support ----------
Avg CSAT = AVERAGE ( vw_support_fact[satisfaction_score] )

Avg Resolution Hrs = AVERAGE ( vw_support_fact[resolution_hours] )

Tickets (by created date) =
CALCULATE ( COUNTROWS ( vw_support_fact ),
            USERELATIONSHIP ( vw_support_fact[created_date], DimDate[Date] ) )

-- ---------- Model ----------
Best Model AUC =
CALCULATE ( MAX ( model_metrics[value] ),
            model_metrics[is_best] = 1, model_metrics[metric] = "ROC_AUC" )

Best Model Name =
CALCULATE ( MAX ( model_metrics[model_name] ), model_metrics[is_best] = 1 )
```

Formatting: Revenue measures → Currency (₹), 0 decimals; % measures → Percentage, 1 decimal.

## 4. Report pages

### Page 1: Executive Overview
- **KPI cards:** Total Revenue, Revenue YoY %, Total Orders, Avg Order Value, Active Customers, Return Rate
- **Line chart:** Total Revenue by DimDate[Month] (add Revenue LY as a second line)
- **Clustered bar:** Total Revenue by products[category]
- **Filled map:** Total Revenue by vw_customer_360[state]
- **Donut:** Total Revenue by payment_method
- **Slicers:** Year, membership_tier, acquisition_channel

### Page 2: Churn Risk (the ML page, which should be your strongest)
- **KPI cards:** Scored Customers, High Risk Customers, Predicted Churn Rate, Revenue at Risk, Potential Savings
- **Donut:** count of customers by risk_segment (colours: High = red, Medium = amber, Low = green, Inactive = grey)
- **Matrix:** membership_tier (rows) × acquisition_channel (columns), values = Avg Churn Risk, with conditional-format background (red scale)
- **Bar:** count of customers by top_driver, which shows *why* customers leave
- **Table (retention call list):** customer_id, city, membership_tier, churn_probability, top_driver, revenue_at_risk; filter risk_segment = High and sort by revenue_at_risk descending
- **Histogram:** binned churn_probability (create a 0.1 bin group)

### Page 3: Customer Segments (RFM / KMeans)
- **Scatter:** frequency (X) vs monetary (Y), Legend = segment_name, Size = revenue_at_risk
- **Clustered column:** count of customers by segment_name, split by risk_segment
- **Table:** segment_name with avg recency_days, avg frequency, avg monetary

### Page 4: Support & Experience
- **KPIs:** Avg CSAT, Avg Resolution Hrs, Tickets
- **Bar:** tickets by category
- **Column:** Avg Churn Risk by binned satisfaction (shows the support → churn link)

### Page 5: Model Performance
- **Cards:** Best Model Name, Best Model AUC
- **Clustered bar:** model_metrics, with Axis = metric, Legend = model_name, Values = value
- **Bar:** feature_importance (top 10 features by importance)
- **Text box:** "Out-of-time validation: trained on the Jul-2025 snapshot, tested on the Oct-2025 snapshot"

## 5. Polish (this is what makes it look professional)
- Use one theme (View → Themes) with a dark navy header bar and consistent fonts
- Add **drill-through**: right-click a customer → "Customer Detail" page showing their orders and tickets
- Add **tooltips pages** for the map and the risk matrix
- Add **bookmarks + buttons** for page navigation
- Turn on **Edit interactions** so the slicers filter only the relevant visuals
- Publish to the Power BI Service and set up a scheduled refresh (mention this in interviews)
