"""
Generates a realistic synthetic e-commerce dataset and loads it into SQLite.

Each customer gets a hidden "churn hazard" driven by tier, channel, discount
habit and service experience. Orders stop after their (hidden) churn date,
so the ML model has real, learnable signal - just like production data.

Usage:  python data/generate_data.py
Output: outputs/ecommerce.db
"""
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N_CUSTOMERS = 5000
START = date(2024, 1, 1)
END = date(2025, 12, 31)          # snapshot date
ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "outputs" / "ecommerce.db"

rng = np.random.default_rng(SEED)

CITIES = {
    "Mumbai": "Maharashtra", "Pune": "Maharashtra", "Delhi": "Delhi",
    "Bengaluru": "Karnataka", "Hyderabad": "Telangana", "Chennai": "Tamil Nadu",
    "Kolkata": "West Bengal", "Lucknow": "Uttar Pradesh", "Jaipur": "Rajasthan",
    "Ahmedabad": "Gujarat", "Dhanbad": "Jharkhand", "Patna": "Bihar",
}
CATEGORIES = {
    "Electronics": (800, 40000), "Fashion": (300, 4000), "Home & Kitchen": (200, 8000),
    "Beauty": (150, 2500), "Books": (100, 1200), "Sports": (300, 6000), "Grocery": (50, 800),
}


def days_between(a, b):
    return (b - a).days


def make_products():
    rows, pid = [], 1
    for cat, (lo, hi) in CATEGORIES.items():
        for i in range(1, 31):
            price = round(float(np.exp(rng.uniform(np.log(lo), np.log(hi)))), 2)
            rows.append((pid, f"{cat} Item {i:02d}", cat, price))
            pid += 1
    return pd.DataFrame(rows, columns=["product_id", "product_name", "category", "unit_price"])


def make_customers():
    total_days = days_between(START, END) - 120
    cities = list(CITIES)
    df = pd.DataFrame({
        "customer_id": np.arange(1, N_CUSTOMERS + 1),
        "gender": rng.choice(["Male", "Female"], N_CUSTOMERS, p=[0.52, 0.48]),
        "age": np.clip(rng.normal(32, 9, N_CUSTOMERS).round(), 18, 70).astype(int),
        "city": rng.choice(cities, N_CUSTOMERS),
        "signup_date": [START + timedelta(days=int(d)) for d in rng.integers(0, total_days, N_CUSTOMERS)],
        "acquisition_channel": rng.choice(["Organic", "Paid Ads", "Referral", "Social"],
                                          N_CUSTOMERS, p=[0.35, 0.30, 0.15, 0.20]),
        "membership_tier": rng.choice(["Basic", "Silver", "Gold"], N_CUSTOMERS, p=[0.60, 0.28, 0.12]),
    })
    df["state"] = df["city"].map(CITIES)
    return df


def simulate(customers, products):
    orders, items, tickets = [], [], []
    oid = iid = tid = 1
    prod_by_cat = {c: g for c, g in products.groupby("category")}
    cat_names = list(CATEGORIES)

    tier_eff = {"Basic": 1.0, "Silver": 0.65, "Gold": 0.35}
    chan_eff = {"Organic": 0.8, "Paid Ads": 1.3, "Referral": 0.6, "Social": 1.1}
    tier_freq = {"Basic": 0.9, "Silver": 1.3, "Gold": 1.8}

    for c in customers.itertuples():
        # latent behaviour
        service_quality = rng.beta(5, 2)                 # 0 bad .. 1 great
        discount_seeker = rng.random() < 0.3
        hazard = (1 / 300) * tier_eff[c.membership_tier] * chan_eff[c.acquisition_channel]
        hazard *= (1.8 - 1.4 * service_quality) * (1.4 if discount_seeker else 1.0)
        hazard *= 1.25 if c.age < 25 else 1.0
        churn_day = c.signup_date + timedelta(days=int(rng.exponential(1 / hazard)))
        active_end = min(churn_day, END)

        # orders: Poisson process (mean gap depends on tier)
        mean_gap = 35 / tier_freq[c.membership_tier]
        d = c.signup_date + timedelta(days=int(rng.integers(0, 10)))
        fav = rng.choice(cat_names, 2, replace=False)
        while d <= active_end:
            status = rng.choice(["Delivered", "Returned", "Cancelled"],
                                p=[0.86 + 0.06 * service_quality - 0.06, 0.08, 0.06 - 0.06 * service_quality + 0.06])
            orders.append((oid, c.customer_id, d.isoformat(), status,
                           rng.choice(["UPI", "Card", "COD", "Wallet"], p=[0.45, 0.25, 0.2, 0.1])))
            for _ in range(int(rng.integers(1, 4))):
                cat = fav[0] if rng.random() < 0.5 else (fav[1] if rng.random() < 0.5 else rng.choice(cat_names))
                p = prod_by_cat[cat].sample(1, random_state=int(rng.integers(1e9))).iloc[0]
                disc = round(float(rng.uniform(15, 40) if discount_seeker else rng.uniform(0, 12)), 1)
                items.append((iid, oid, int(p.product_id), int(rng.integers(1, 3)), float(p.unit_price), disc))
                iid += 1
            oid += 1
            d += timedelta(days=max(1, int(rng.exponential(mean_gap))))

        # support tickets: more when service quality is poor
        n_tickets = rng.poisson(0.5 + 4 * (1 - service_quality))
        span = max(1, days_between(c.signup_date, min(active_end + timedelta(days=15), END)))
        for _ in range(n_tickets):
            td = c.signup_date + timedelta(days=int(rng.integers(0, span)))
            sat = int(np.clip(round(rng.normal(1 + 4 * service_quality, 0.8)), 1, 5))
            tickets.append((tid, c.customer_id, td.isoformat(),
                            rng.choice(["Delivery", "Refund", "Product Quality", "Payment"]),
                            round(float(rng.gamma(2, 6 + 30 * (1 - service_quality))), 1), sat))
            tid += 1

    return (pd.DataFrame(orders, columns=["order_id", "customer_id", "order_date", "status", "payment_method"]),
            pd.DataFrame(items, columns=["order_item_id", "order_id", "product_id", "quantity", "unit_price", "discount_pct"]),
            pd.DataFrame(tickets, columns=["ticket_id", "customer_id", "created_date", "category",
                                           "resolution_hours", "satisfaction_score"]))


def main():
    DB_PATH.parent.mkdir(exist_ok=True)
    if DB_PATH.exists():
        DB_PATH.unlink()
    con = sqlite3.connect(DB_PATH)
    con.executescript((ROOT / "sql" / "schema.sql").read_text())

    products = make_products()
    customers = make_customers()
    orders, items, tickets = simulate(customers, products)
    customers["signup_date"] = customers["signup_date"].astype(str)

    for name, df in [("customers", customers), ("products", products), ("orders", orders),
                     ("order_items", items), ("support_tickets", tickets)]:
        df.to_sql(name, con, if_exists="append", index=False)
        print(f"{name:16s} {len(df):>7,} rows")
    con.close()
    print(f"\nDatabase written to {DB_PATH}")


if __name__ == "__main__":
    main()
